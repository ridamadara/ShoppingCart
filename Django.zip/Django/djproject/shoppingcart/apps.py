from django.apps import AppConfig


class ShoppingcartConfig(AppConfig):
    name = 'shoppingcart'
