# import mysql.connector
#
# mydb = mysql.connector.connect(
#   host="localhost",
#   user="root",
#   password="root",
# database="online_shopping_cart"
# )
#
# #mycursor = mydb.cursor()
#
#
#
# #mycursor.execute("SHOW TABLES")
#
#
# #for x in mycursor:
# #     print(x)
# print(mydb)