# import test
# mycursor = test.mydb.cursor()
#
# mycursor.execute("SHOW TABLES")
#
#
# for x in mycursor:
#      print(x)